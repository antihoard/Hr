<?php //copy from default_lang.php file and update

$lang["hr_profile_example"] = "Example";

return $lang;