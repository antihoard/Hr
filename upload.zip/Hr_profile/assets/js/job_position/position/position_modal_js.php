<script>
	
	$(document).ready(function () {
		$("#job_position-form .select2").select2();
	});
</script>

