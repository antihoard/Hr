 <div class="col-md-12"><h4><?php echo app_lang('bonus'); ?></h4><hr></div>

 <table class="table table-general_bonus scroll-responsive">
 	<thead>
 		<tr>
 			<th><?php echo app_lang('name_bonus'); ?></th>
 			<th><?php echo app_lang('hr_criteria'); ?></th>
 			<th><?php echo app_lang('time'); ?></th>
 			<th><?php echo app_lang('forms'); ?></th>
 			<th><?php echo app_lang('value_'); ?></th>                                             
 		</tr>
 	</thead>
 	<tbody></tbody>
 	<tfoot>
 		<td></td>
 		<td></td>
 		<td></td>
 		<td></td>                                  
 	</tfoot>
 </table>
 <div class="col-md-12"><h4><?php echo app_lang('discipline'); ?></h4><hr></div>

 <table class="table table-general_discipline scroll-responsive">
 	<thead>
 		<tr>
 			<th><?php echo app_lang('name_discipline'); ?></th>
 			<th><?php echo app_lang('hr_criteria'); ?></th>
 			<th><?php echo app_lang('time'); ?></th>
 			<th><?php echo app_lang('forms'); ?></th>                                     
 			<th><?php echo app_lang('value_'); ?></th>                                             
 		</tr>
 	</thead>
 	<tbody></tbody>
 	<tfoot>
 		<td></td>
 		<td></td>
 		<td></td>
 		<td></td>                                  
 	</tfoot>
 </table>